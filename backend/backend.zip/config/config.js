
module.exports={
    DB_HOST:"localhost",
    DB_USER:"root",
    DB_PASSWORD:"",
    DB_NAME:"system_support",
    CLIENT_URL : "http://localhost:5173"

}